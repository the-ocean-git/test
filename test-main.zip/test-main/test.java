package testJava;
public class testProject { 
public static void main(String[] args) { 
  println("hello, world");
  } 
}
